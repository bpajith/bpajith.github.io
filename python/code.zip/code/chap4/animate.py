from matplotlib.animation import FuncAnimation as fa
from pylab import *

x = linspace(-2*pi, 2*pi, 100)
fig1 = figure()
L, =  plot(x, sin(x))

def update(fnum):
	print(fnum)
	L.set_data(x, sin(x + 0.1 * fnum))
	return L,

anim = fa(fig1, update, frames=100, interval=50)
show()
