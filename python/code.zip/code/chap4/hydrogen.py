from numpy import * 
from pylab import * 
from scipy.special import sph_harm 
from scipy.special import genlaguerre
import scipy.misc

from mpl_toolkits.mplot3d import Axes3D
ax = Axes3D(figure())

polar = linspace(0,pi,100) 
azimuth = linspace(0, 2*pi,100) 
phi,th = meshgrid(polar, azimuth)



r0 = 1
n = 4
l = 2
m = 1
a0 = 1

#r = (2*r0/n/a0)**l * exp(-r0/n/a0) * genlaguerre(n-l-1,2*l+1)(2*r0/n/a0) * sph_harm(m,l,phi,th)

r = (2*r0/n/a0)**l * exp(-r0/n/a0) * genlaguerre(n-l-1,2*l+1)(2*r0/n/a0) *  sph_harm(m,l,phi,th)

x = r*sin(phi)*cos(th) 
y = r*cos(phi) 
z = r*sin(phi)*sin(th)

ax.plot_surface(x,y,z, rstride=1, cstride=1,cmap='viridis', edgecolor='none') 
show()
