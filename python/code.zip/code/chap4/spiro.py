from pylab import *

t = linspace(0, 10*pi, 500)		
r = 3.
R = 10.0
k = r/R
l = 1.4

x = R*((1-k)*cos(t) + l*k*cos((1-k)*t/k)) 
y = R*((1-k)*sin(t) - l*k*sin((1-k)*t/k)) 
plot(x,y)
show()
