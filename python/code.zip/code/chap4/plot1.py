#Example plot1.py

from pylab import *
data = [1,2,5]
plot(data)
show()
