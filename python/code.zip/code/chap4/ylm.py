
from pylab import * 
from scipy.special import sph_harm
from mpl_toolkits.mplot3d import Axes3D
ax = Axes3D(figure())

phi = linspace(0,pi,50) 
theta = linspace(0, 2*pi, 50) 
phi,theta = meshgrid(phi, theta)

#r = 0.25 * sqrt(5.0/pi) * (3*cos(phi)**2 - 1)
m, l = 0,2

fcolors = sph_harm(m, l, theta, phi).real
fmax, fmin = fcolors.max(), fcolors.min()
fcolors = (fcolors - fmin)/(fmax - fmin)

r = fcolors *0.5
x = r*sin(phi)*cos(theta) 
y = r*cos(phi) 
z = r*sin(phi)*sin(theta)

coeff = np.sqrt((2.0/n)**3 * spe.factorial(n-l-1) /(2.0*n*spe.factorial(n+l)))

laguerre = spe.assoc_laguerre(2.0*r/n,n-l-1,2*l+1)

sphHarm = spe.sph_harm(m,l,phi,theta) # Note the different convention from doc

return coeff * np.exp(-r/n) * (2.0*r/n)**l * laguerre * sphHarm

ax.plot_surface(x,y,z, rstride=1, cstride=1,facecolors=cm.seismic(fcolors)) 
show()
