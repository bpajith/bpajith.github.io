#Example plot4.py

from pylab import *

t = arange(0.0, 5.0, 0.2)

plot(t, t**2,'x', label='t^2')      # t^{2}

plot(t, t**3,'ro', label='t^3')     # t^{3}

legend(framealpha=0.5)

show()
