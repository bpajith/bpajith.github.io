from pylab import *
subplot(211)             # the first subplot
plot([1,2,3,4])
xlabel('first row')
subplot(212)             # the second subplot
plot([4,2,3,1])
xlabel('second row')
show()
