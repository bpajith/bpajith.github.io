from pylab import *
from mpl_toolkits.mplot3d import Axes3D
ax = Axes3D(figure())

x = linspace(-5, 5, 50)
y = linspace(-5, 5, 50)
xx, yy = meshgrid(x, y)
z = sin(sqrt(xx ** 2 + yy ** 2)) #sin(xx) + sin(yy) 

ax.contour3D(xx, yy, z, 50, cmap=cm.jet)
show()

