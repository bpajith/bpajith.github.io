'''
Solving initial value problem using 4th order Runge-Kutta method.
The mass-spring problem
Second order differential equation. Integrated twice using an array.
In fxy(x,y), y is an array : y[0] = displacement, y[1] = velocity
'''

from pylab import *

def fxy(x,y):
	m = 10.0	# mass
	k = 100.0  # spring constant
	force = -k * y[0] # - 2. * y[1]  # damping
	accn = force/m   # accn = force /mass
	vel = y[1]
	return array([vel, accn])

def rk4(x, y, fxy, h):   # x, y , f(x,y)
	k1 = h * fxy(x, y)
	k2 = h * fxy(x+h/2.0, y+k1/2)
	k3 = h * fxy(x+h/2.0, y+k2/2)
	k4 = h * fxy(x+h, y+k3)
	ny = y + ( k1/6 + k2/3 + k3/3 + k4/6 )
	#print x,y,k1,k2,k3,k4, ny
	return ny


y = [10.0,0.0]
h = .01    # stepsize
x = 0.0    # initail values

time = [x]
pos = [y[0]]
vel = [y[1]]

while x < 15.0:
	#print x, y[0], y[1]
	y = rk4(x,y,fxy,h)
	x = x + h
	time.append(x)
	pos.append(y[0])
	vel.append(y[1])
plot(time, pos)
plot(time, vel)
show()

