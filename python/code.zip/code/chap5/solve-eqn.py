def invert(m):    
	m1, m2, m3 = m[0]
	m4, m5, m6 = m[1]
	m7, m8, m9 = m[2]
	d = m1*(m5*m9-m6*m8) - m2*(m4*m9-m6*m7) + m3*(m4*m8-m5*m7) 
	return [[(m5*m9-m6*m8)/d, (m3*m8-m2*m9)/d, (m2*m6-m3*m5)/d],
		    [(m6*m7-m4*m9)/d, (m1*m9-m3*m7)/d, (m3*m4-m1*m6)/d],
            [(m4*m8-m5*m7)/d, (m2*m7-m1*m8)/d, (m1*m5-m2*m4)/d] ]

a = [ [4.,1.,-2.], [2.,-3.,3.], [-6.,-2.,1.] ]    

a = invert(a)
 
b = [ [0], [9], [0] ]  # 3 x 1
c = [ [0], [0], [0] ]           # 3 x 1

NR = len(a)     # number of rows
NC = len(b[0])  # number of columns

for row in range(NR):
	for col in range(NC):
		for i in range(len(a[0])):	 # number of columns of A
			c[row][col] += a[row][i] * b[i][col]
print (c)
