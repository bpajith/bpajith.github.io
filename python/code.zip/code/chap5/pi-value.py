from random import random
from math import sqrt

NP = 100000
inside = 0

for k in range(NP):
	x = random()
	y = random()
	r = sqrt(x**2 + y**2) 
	if  r <= 1:
		inside += 1

ratio = inside / NP
print (4*ratio)
