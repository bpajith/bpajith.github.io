from numpy import *
        
x = 1./360  
sinx = 0
for n in range(3):
	term = (-1)**(n) * (x**(2*n+1)) / math.factorial(2*n+1)
	sinx = sinx + term
	print (sinx,term)
        
print(sin(x))
