from numpy import *

x = [0,2,4,6]
y = [0,8,64,216]
n = len(x)

for a in x: print('%10.0f'%a, end= '')
print()
for a in y: print('%10.0f'%a, end = '')
print()

deltas = []   # list to store the required Delta values
 
diff = copy(y)
for k in range(0,n-1):   
	tmp = copy(diff)     
	print((k+1)*5*' ', end = '') # adjust spacing
	for i in range(k,n-1):
		tmp[i+1] = (diff[i+1] - diff[i])
		print('%10.0f'%tmp[i+1], end = '')
	print()
	deltas.append(tmp[k+1])   
	diff = copy(tmp)
print ('Delta values ',deltas)


nx = 2.5
h = x[1] - x[0]
p = (nx-x[0])/h
print('p = ', p)
ny = y[0] + p*deltas[0] + p*(p-1)*deltas[1]/2 + p*(p-1)*(p-2)*deltas[2]/6
print (ny, nx**3)

