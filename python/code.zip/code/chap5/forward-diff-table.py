from numpy import *

x = [0,1,2,3]
y = [0,1,8,27]
n = len(x)

for a in x: print('%10.0f'%a, end= '')
print()
for a in y: print('%10.0f'%a, end = '')
print()

for k in range(0,n-1):   
	tmp = copy(y)     
	print((k+1)*5*' ', end = '') # adjust spacing
	for i in range(k,n-1):
		tmp[i+1] = (y[i+1] - y[i]) / (x[i+1]-x[i-k])
		print('%10.0f'%tmp[i+1], end = '')
	print()
	y = copy(tmp)
print ('coefficients ',y)

