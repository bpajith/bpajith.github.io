from numpy import *

x = [0, .5, 1.5, 3]
y = [0, .125, 3.375, 27]
n = len(x)

for a in x: print('%10.2f'%a, end= '')
print()
for a in y: print('%10.2f'%a, end = '')
print()

for k in range(0,n-1):   
	tmp = copy(y)     
	print((k+1)*5*' ', end = '') # adjust spacing
	for i in range(k,n-1):
		tmp[i+1] = (y[i+1] - y[i]) / (x[i+1]-x[i-k])
		print('%10.2f'%tmp[i+1], end = '')
	print()
	y = copy(tmp)
print ('coefficients ',y)

#verification
a = y
nx = 2.5
ny = a[0] + (nx - x[0])*a[1] + (nx - x[0])*(nx - x[1])*a[2] + \
	(nx - x[0])*(nx - x[1])*(nx - x[2])*a[3]
print(ny, nx**3)

	
