from numpy import *

x = [0, .5, 1.5, 3]
y = [0, .125, 3.375, 27]
n = len(x)

for k in range(0,n-1):   
	tmp = copy(y)     
	for i in range(k,n-1):
		tmp[i+1] = (y[i+1] - y[i]) / (x[i+1]-x[i-k])
	y = copy(tmp)
print ('coefficients ',y)

