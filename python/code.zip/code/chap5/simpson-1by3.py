from math import *

def sqr(a):
	return sqrt(1.0 - a**2)

def simp13(f, a, b, n):
	h = (b-a) / n
	result = f(a)    # first point
	for i in range (1,n,2):
		result = result + 4 * f(a + h * i)
	for i in range (2,n-1,2):
		result = result + 2 * f(a + h * i)
	
	result = result + f(b)  # last point
	return  h/3 * result


print(4*simp13(sqr,0.,1.,100))
print(4*simp13(sqr,0.,1.,1000))

