from math import *

def sqr(a):
	return sqrt(1.0 - a**2)

def trapez(f, a, b, n):
	h = (b-a) / n
	result = f(a)    # first point
	for i in range (1,n):
		result = result + 2 * f(a + h * i)
	result = result + f(b)  # last point
	return 0.5 * h * result

print(4*trapez(sqr,0.,1.,100))
print(4*trapez(sqr,0.,1.,1000))

