from pylab import *

x = [0, .5, 1.5, 3]
y = [0, .125, 3.375, 27]
a = array([0,.25, 2, 1])  #coefficients calculated by forward-diff.py

nx = linspace(0,3,11)  # 11 equispaced values of x from 0 to 3

ny = a[0] + (nx - x[0])*a[1] + (nx - x[0])*(nx - x[1])*a[2] + \
	(nx - x[0])*(nx - x[1])*(nx - x[2])*a[3]

plot(x,y, 'o')    # given data points

#print (ny, nx**3)
plot(nx,ny,'+')       # interpolated points
plot(nx,nx**3,'x')    # exact values
show()
