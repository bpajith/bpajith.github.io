from numpy import *

x  = array([0,1,2,3])
y  = array([0,3,14,39])
n = len(x)
tmp = copy(y)
for k in range(1,n):
	tmp[k:n] = (tmp[k:n] - tmp[k-1])/(x[k:n]-x[k-1])
print(tmp)

