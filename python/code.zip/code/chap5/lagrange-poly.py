
xa = [0, .5, 1.5, 3]
ya = [0, .125, 3.375, 27]
N = len(xa)

def lagra(x): 
	res = 0.0
	
	for i in range(N):
		term = 1 
		for k in range(N):
			if i != k:
				#print (x, xa[k], xa[i], xa[k])
				term = term * (x - xa[k]) / (xa[i]-xa[k])
		#print (term)
		res += term * ya[i]		
	return res

print (lagra(2.5), 2.5**3)
