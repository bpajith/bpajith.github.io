from numpy import *

a = array( [ [2,1,-1, 1,0,0], [-3,-1,2, 0,1,0], [-2,1,2, 0,0,1] ],dtype='float')
NR = len(a)
NC = NR + 3     # one more column, Augmented matrix

for anchor in range(NR-1):
	for row in range(anchor, NR-1):
		print('anchor = %2d row = %2d\n'%(anchor,row))
		ratio = a[row+1,anchor]/a[anchor,anchor]
		a[row+1] = subtract(a[row+1],a[anchor]*ratio)
		print (a,'\n')
	
for anchor in range(NR-1, 0,-1):   # looping for 2, 1, 
	for row in range(anchor):  
		print('anchor = %2d row = %2d\n'%(anchor,row))
		ratio = a[row,anchor]/a[anchor,anchor]
		a[row] = subtract(a[row],a[anchor]*ratio)
		print (a,'\n')

for row in range(NR):		#making all diagonal elements 1.
	if a[row,row] != 1:
		a[row] = a[row] / a[row,row]    
print (a,'\n')
ia = a[:,3:6]  # extract columns 3,4,5
print (ia, '\n')


#verify by multiplying the input matrix with the inverse.
z = array( [ [2,1,-1], [-3,-1,2], [-2,1,2] ],dtype='float')
ia = a[:,3:6]
print(z, '\n')
print(ia@z) 

