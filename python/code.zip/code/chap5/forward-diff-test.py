from pylab import *

x = [0,1,2,3]
y = [0,1,8,27]
n = len(x)

a = [0,1,3,1]   #from FD table

nx = linspace(0,3,11)  # 11 equispaced values of x from 0 to 3

h = x[1] - x[0]
p = (nx-x[0])/h

ny = a[0] + p*a[1] + p*(p-1)*a[2] + p*(p-1)*(p-2)*a[3]

plot(x,y, 'o')    # given data points
plot(nx,ny, 'x')  # interpolated points
show()
