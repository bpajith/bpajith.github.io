# Generate and save two column data to file 
from pylab import *

t = linspace(0,10,11)
s = 5 * t**2
dat = array([t,s])
savetxt('diff-data.txt', dat, delimiter = ' ')
