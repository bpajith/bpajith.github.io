from pylab import *

x = [0,1,2,3]
y = [0,1,8,27]
a = [0,1,3,1]   #coefficients from FD table

h = x[1] - x[0]
nx = 1.5		# new point
p = (nx-x[0])/h

dny = a[1] + (2*p-1)*a[2] + (3*p**2-6*p+2)*a[3]
print  (dny, 3*nx**2)
