#Example inv.py

from numpy import *

th = pi/4

R = array( (cos(th), -sin(th)), (sin(th), cos(th)))
print (R)

Pold = array( ((1),(3)))
print (R*Pold)



'''
a = array([ [4,1,-2], [2,-3,3], [-6,-2,1] ], dtype='float')
ainv = linalg.inv(a)
print(ainv)
print((dot(a,ainv)))
'''
