from pylab import *

x = linspace(0, 2*pi, 100)
plot (sin(x))
show()
