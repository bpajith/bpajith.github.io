from numpy import *
a = array([1,10,100,1000])
print(log10(a))
