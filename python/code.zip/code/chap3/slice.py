from numpy import *

x = reshape(range(12),(4,3))
print(x[1])
print(x[2,1])
print(x[1:3,1])
print(x[:,1])
print(x[:2,:2])



