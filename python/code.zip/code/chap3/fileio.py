#Example fileio.py

from numpy import *
a = array([[2,3], [4,5]])
print(a)
savetxt('mydata.txt', a, fmt = '%.3f', delimiter = ' ')
print('Data saved to text file')

b = loadtxt("mydata.txt", delimiter=' ')
print('Data loaded from text file')
print(b)
