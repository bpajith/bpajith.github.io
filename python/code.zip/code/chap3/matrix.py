
from numpy import *

a = array([[2,3], [4,5]])
b = array([[7,8], [1,0]])
print (a*b, '\n')

a = mat([[2,3], [4,5]])
b = mat([[7,8], [1,0]])
print (a*b)
