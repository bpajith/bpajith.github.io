
from numpy import *

a = matrix([ [3, 1, 4], [1, 5, 9], [2, 6, 5] ])
print ('matrix a \n', a, '\n')
print ('transpose\n', a.T, '\n')
print ('Hermitian transpose\n', a.H, '\n')
print ('Inverse\n', a.I, '\n')
print ('a * a.I = I\n', a * a.I, '\n')
