from numpy import *

sx = array( [ [0+0j, 1+0j], [1+0j, 0+0j] ])    # sigma x
sy = array( [ [0+0j, 0-1j], [0+1j, 0+0j] ])    # sigma y
sz = array( [ [1+0j, 0+0j], [0+0j, -1+0j] ])   # sigma z 

print ('sx\n', sx)
print ('Transpose(sx)\n', transpose(sx))

commutexy = sx.dot(sy) - sy.dot(sx)
print ('[sx,sy]\n',commutexy)

sz2i = 2 * (0+1j) * sz
print ('2 i sz\n',sz2i)

print (sz2i == commutexy)
