#Example numpy3.py

from numpy import *
a = [ [1,2] , [3,4] ] # make a list of lists
x = array(a)    # and convert to an array
print(a)
