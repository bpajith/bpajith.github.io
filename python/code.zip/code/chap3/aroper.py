from numpy import *

x = ones( (2,2,))
print(x*5)
print(x * x)
print(x @ x)


