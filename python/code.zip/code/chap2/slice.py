a = 'hello world'
print(a[3:5])
print(a[6:])
print(a[:5])
