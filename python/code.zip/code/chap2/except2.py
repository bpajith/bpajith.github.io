def get_number():
   while 1:
      try:
         a = input('Enter a number ')
         x = eval(a)
         return x
      except:
         print('Enter a valid number')

print(get_number())
