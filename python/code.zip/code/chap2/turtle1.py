from turtle import *

a = Pen()    # Creates a graphics window
a.forward(50)
a.left(45)
a.backward(50)
a.right(45)
a.forward(50)
a.circle(10)
a.up()
a.forward(50)
a.down()
a.color('red')
a.right(90)
a.forward(50)
input('Press Enter') 
