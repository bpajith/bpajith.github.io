import sys
from PyQt5.QtWidgets import QApplication, QWidget

class MyGUI(QWidget):
	def __init__(self):
		super().__init__()
		self.setWindowTitle('My First Object Oriented Qt Window')
		self.show()
        	
app = QApplication(sys.argv)
win = MyGUI()
sys.exit(app.exec_())
