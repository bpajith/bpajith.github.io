#Example: forloop2.py

for item in range(5):
    print(item)
