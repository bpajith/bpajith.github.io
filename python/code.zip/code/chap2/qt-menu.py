import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton

class MyGUI(QMainWindow):
	def __init__(self):
		super().__init__()
		self.setWindowTitle('Button and callback in Qt')
		self.setGeometry(300, 300, 300, 200)
		mainMenu = self.menuBar()
		fileMenu = mainMenu.addMenu('File')
		fileMenu.addAction('Open',self.fileOpen)
		editMenu = mainMenu.addMenu('Edit')
		self.show()
	
	def fileOpen(self):
		print ('File Open called')
        	
app = QApplication(sys.argv)
win = MyGUI()
sys.exit(app.exec_())
