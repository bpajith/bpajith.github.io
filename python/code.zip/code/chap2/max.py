#Example: max.py

max = 0

while True:        # Infinite loop
   x = eval(input('Enter a number '))
   if x > max:
      max = x
   if x == 0:
      print(max)
      break
