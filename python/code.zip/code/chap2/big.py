#Example: big.py

x = eval(input('Enter a number '))

if x > 10:
    print('Bigger Number')
elif x < 10:
    print('Smaller Number')
else:
    print('Same Number')
