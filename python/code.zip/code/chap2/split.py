s = 'I am a long string'
print(s.split())
a = 'abc.abc.abc'
aa = a.split('.')
print(aa)
mm = '+'.join(aa)
print(mm)