#mat-1.py

a = [ [1,2], [3,4] ]
print (a[1][0])
print ('NR = ', len(a), 'NC = ', len(a[0]))


n = 5
for row in range(2):
	for col in range(2):
		a[row][col] *= n	
print(a)	
