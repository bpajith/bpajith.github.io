a = 'hello'+'world'
print(a)
b = 'ha' * 3
print(b)
print(a[-1] + b[0])