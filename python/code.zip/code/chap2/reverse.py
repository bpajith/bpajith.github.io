a = 'abcd'
b = ''
for k in range(len(a)):
	b = b + a[-1-k]
print(b)
