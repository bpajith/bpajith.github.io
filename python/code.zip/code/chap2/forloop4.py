a = [2, 5, 3, 4, 12]
size = len(a)
for k in range(size):
		a[k] = 0
print(a)
		
