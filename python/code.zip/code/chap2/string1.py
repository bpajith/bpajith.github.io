s = 'hello world'
print(s[0])             # print first element, h
print(s[1])             # print e
print(s[-1])            # will print the last character