#Example: area.py

pi = 3.1416
r = eval(input('Enter Radius '))
a = pi * r ** 2       #A=\pi r^{2}
print('Area = ', a)
