
def invert(m):    
	m1, m2, m3 = m[0]
	m4, m5, m6 = m[1]
	m7, m8, m9 = m[2]
	d = m1*(m5*m9-m6*m8) - m2*(m4*m9-m6*m7) + m3*(m4*m8-m5*m7) 
	print(d)
	return [[(m5*m9-m6*m8)/d, (m3*m8-m2*m9)/d, (m2*m6-m3*m5)/d],
		    [(m6*m7-m4*m9)/d, (m1*m9-m3*m7)/d, (m3*m4-m1*m6)/d],
            [(m4*m8-m5*m7)/d, (m2*m7-m1*m8)/d, (m1*m5-m2*m4)/d] ]
            
                   
a = [ [1.,1.,1.], [0.,2.,5.], [2.,5.,-1.] ]                            
print (invert(a))
