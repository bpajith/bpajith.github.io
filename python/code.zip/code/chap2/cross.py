from numpy import cross

def mycross2(a,b):
	a1, a2, a3 = a
	b1, b2, b3 = b
	return [a2*b3 - a3*b2, a3*b1 - a1*b3, a1*b2 - a2*b1]
	
def mycross(a,b):
	return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]
	
a = [1,2,3]
b = [4,5,6]

print(cross(a,b))
print(mycross(a,b))
print(mycross2(a,b))
