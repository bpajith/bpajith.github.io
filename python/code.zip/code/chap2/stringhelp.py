s = 'hello world'
print(len(s))
print(s.upper())
help(str)          # press q to quit help