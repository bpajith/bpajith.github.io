import sys
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton

class MyGUI(QWidget):
	def __init__(self):
		super().__init__()
		self.setWindowTitle('Button and callback in Qt')
		self.setGeometry(300, 300, 300, 200)
		btn = QPushButton('Exit Button', self)
		btn.clicked.connect(self.done)
		self.show()
		
	def done(self):
		sys.exit(0)
        	
app = QApplication(sys.argv)
win = MyGUI()
sys.exit(app.exec_())
