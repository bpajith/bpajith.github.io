
import numpy as np
print(np.random.normal())

import scipy.special
print(scipy.special.j0(.1))

