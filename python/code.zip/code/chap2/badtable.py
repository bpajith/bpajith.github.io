#Example: badtable.py

print(1 * 8)
print(2 * 8)
print(3 * 8)
print(4 * 8)
print(5 * 8)
