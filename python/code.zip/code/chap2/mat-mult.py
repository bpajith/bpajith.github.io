'''
Matrix multiplication
Number of rows in A must be equal to number of columns in B
'''

a = [ [1,2,3], [3,4,5], [10,11,12] ]
b = [ [5,6,7], [7,8,9], [12,13,14] ]
c = [ [0,0,0], [0,0,0], [0,0,0] ]

NR = len(a)     # number of rows
NC = len(b[0])  # number of columns

for row in range(NR):
	for col in range(NC):
		for i in range(len(a[0])):	  # number of columns of A
			c[row][col] += a[row][i] * b[i][col]
print (c)

a = [ [1,2,3], [3,4,5] ]       # 2 x 3
b = [ [5,6], [7,8], [12,13] ]  # 3 x 2
c = [ [0,0], [0,0] ]           # 2 x 2

NR = len(a)     # number of rows
NC = len(b[0])  # number of columns

for row in range(NR):
	for col in range(NC):
		for i in range(len(a[0])):	 # number of columns of A
			c[row][col] += a[row][i] * b[i][col]
print (c)

'''
from numpy import *
a = array([ [1,2,3], [3,4,5], [10,11,12] ])
b = array([ [5,6,7], [7,8,9], [12,13,14] ])

print (a@b)

a = array([ [1,2,3], [3,4,5] ])
b = array([ [5,6], [7,8], [12,13] ])

print (a@b)
'''


